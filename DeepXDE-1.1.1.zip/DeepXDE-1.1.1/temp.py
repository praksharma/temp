import deepxde as dde  # A complete problem: data+PDE+FCNN+optimiser
import numpy as np

# Parameters

#n=2
#precision_train = 10
#precision_test = 30
hard_constraint = False # set constraint type
weights = 100  # if hard_constraint == False

epochs = 15000
# learning rate, the number of dense layers and nodes, and the activation function
parameters = [1e-3, 4, 150, "tanh"]

# # Define sine function
# if dde.backend.backend_name == "pytorch":
#     sin = dde.backend.pytorch.sin
# else:
#     from deepxde.backend import tf

#     sin = tf.sin

learning_rate, num_dense_layers, num_dense_nodes, activation = parameters



def pde(X,u):
    """
    Returns the residual error

    Parameters
    ----------
    x : nd-array
        Independent variables.
    y : nd-array
        Dependent variables.

    Returns
    -------
    float
        The residual error.
    """ 
    dy_xx = dde.grad.hessian(u, X, i=0, j=0)
    dy_yy = dde.grad.hessian(u, X, i=1, j=1)
    
    #x = X[:, 0:1]
    #y = X[:, 1:2]
    #f = k0 ** 2 * sin(k0 * x) * sin(k0 * y)
    return dy_xx + dy_yy

# def boundary_r(x, on_boundary):
#     """
#     Defines the Periodic BC points (not the solution)
#     Returns 1 if x is on the boundary else 0.
#     because of rounding-off error we use np.isclose() to test whether two floating points are equivalent
#     """
#     return on_boundary
    
    
def boundary_left(X, on_boundary):
    """
    Defines the Dirichlet BC points (not the solution)
    The function should return `True` for those points inside the subdomain and `False` for the points outside.
    Returns 1 if x is on the boundary else 0.

    Parameters
    ----------
    x : 1d-array
        x,y,z coodinates of any point.

    Returns
    -------
    boolean
        whether x is on the boundary or not.
    """ 
    x = X[0]
    return on_boundary and np.isclose(x, 0) # when x= 0

def boundary_right(X, on_boundary):
    x = X[0] # # X[:, 0:1] is equivalent to X[:,0]
    return on_boundary and np.isclose(x, 1) # when x= 1

def boundary_bottom(X, on_boundary):
    y = X[1] # X[:, 1:2] is equivalent to X[:,1]
    return on_boundary and np.isclose(y, 0) # when y = 0

def boundary_top(X, on_boundary):
    y = X[1] # X[:, 1:2] is equivalent to X[:,1]
    return np.isclose(X[0],0) and np.isclose(y, 1) # when y = 1

# def func_dirichlet(x):
#     """
#     Returns the prescribed Dirichlet boundary condition.
#     A wayaround is to use lambda function when specifying the BCs
#     Parameters
#     ----------
#     x : 1d-array
#         x,y,z coodinates of any point.
    
#     Returns
#     -------
#     float
#         the prescribed boundary condition at x.
    
#     Example
#     -------
#     If the function value is a constant
#     return 1
    
#     If the function value is not a constant
#         return np.sin(np.pi * x)
#     """ 
#     return 0


# def func_neumann(x):
#     """
#     Returns the prescribed Neumann boundary condition.
#     A wayaround is to use lambda function when specifying the BCs
#     Parameters
#     ----------
#     x : 1d-array
#         x,y,z coodinates of any point.
    
#     Returns
#     -------
#     float
#         the prescribed boundary condition at x.
    
#     Example
#     -------
#     If the function value is a constant
#     return 1
    
#     If the function value is not a constant
#         return np.sin(np.pi * x)
#     """ 
#     return 4 # see the problem

def exact(X):
    """
    Returns the exact solution
    Parameters
    ----------
    x : 1d-array
        x,y,z coodinates of any point.
    
    Returns
    -------
    float
        The exact solution.
    """ 
    #x = X[:, 0:1]
    #y = X[:, 1:2]
    # x[:,1:] and x[:,1:2] are the same for x of size [no_of_samples,2]
    
    return 0 # do not use tf.sin as this is just to plot the curve

geom = dde.geometry.Rectangle(xmin=[0,0], xmax=[1, 1]) # geometry
#k0 = 2 * np.pi * n
#wave_len = 1 / n
#hx_train = wave_len / precision_train
#nx_train = int(1 / hx_train)
#hx_test = wave_len / precision_test
#nx_test = int(1 / hx_test)


if hard_constraint == True:
    bc_left = []
    bc_right = [] 
    bc_bottom = []
    bc_top = [] 
    
else:
    # use lambda function to define the BC solution at each boundary
    bc_left = dde.icbc.DirichletBC(geom, lambda x: 1, boundary_left) # BC(boundary) 
    bc_right = dde.icbc.DirichletBC(geom, lambda x: 1, boundary_right ) # BC(boundary) 
    bc_bottom = dde.icbc.DirichletBC(geom, lambda x: 0, boundary_bottom ) # BC(boundary) 
    bc_top = dde.icbc.DirichletBC(geom, lambda x: 0, boundary_top ) # BC(boundary) 

# bc_rad = dde.icbc.DirichletBC(geom,
#                              lambda x: np.cos(x[:, 1:2]), # remember x[:, 1:2] is theta
#                              boundary_l,
#                              # the same can be implemented as
#                             # lambda x, on_boundary: on_boundary and np.isclose(x[0], 1),                 
#                                 )

#bc_l = dde.icbc.DirichletBC(geom, lambda x: 0, boundary_l) # BC (dirichlet)
#bc_r = dde.icbc.PeriodicBC(geom, 0, boundary_r) # Periodic condition
# Example: bc_r = dde.icbc.NeumannBC(geom, lambda X: 2*(X+1), boundary_r)
# bc_r = dde.icbc.NeumannBC(geom, 4, boundary_r) will give error as int is not callable 

# 1200: no. of collocation points
# 120: no. of BC points
# num_test: no residual points for testing
data = dde.data.PDE(
    geom,
    pde,
    [bc_left, bc_right, bc_bottom, bc_top],
    num_domain = 2500,
    num_boundary = 200, # the BC are prescribed on 2D domain so we have lot more points
    #solution = exact, # we don't know the exact solution
    #num_test = nx_test ** 2
)

extra_data = np.random.rand(3,2)

data.test_x = np.vstack ([data.test_x,extra_data])
data.test_x = data.test_x.astype("float32")
data.train_x = np.vstack ([data.train_x,extra_data])
data.train_x = data.train_x.astype("float32")
#layer_size = [2] + [20]*3 + [1] # [1, 50, 50, 50, 1]
#activation = "tanh"
#initialiser = "Glorot normal"
net = dde.nn.FNN(
    [2] + [num_dense_nodes] * num_dense_layers + [1],
    activation,
    "Glorot uniform"
) # creating a neural network

# Apply the feature transform
#net.apply_feature_transform(feature_transform)

# if hard_constraint == True: # transform the NN
#     net.apply_output_transform(transform)

model = dde.Model(data, net)  # defining the model

# if hard_constraint == True:
#     model.compile("adam", lr=learning_rate, metrics=["l2 relative error"])
# else:
#     loss_weights = [1, weights] # soft contraint
#     model.compile(
#         "adam",
#         lr=learning_rate,
#         metrics=["l2 relative error"],
#         loss_weights=loss_weights,)

model.compile("adam",
              lr=1e-3,
              #metrics=["l2 relative error"], # we don't have the testing dataset (true solution)
            ) # setting the optimiser

losshistory, train_state = model.train(epochs=5)#, model_save_path="model/model.ckpt")




#%%
import matplotlib.pyplot as plt
plt.scatter(data.train_x_bc[:,0],data.train_x_bc[:,1])



