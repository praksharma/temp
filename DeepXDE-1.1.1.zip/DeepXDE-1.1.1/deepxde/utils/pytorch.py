"""Utilities of pytorch."""
