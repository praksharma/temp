"""Package for pytorch NN modules."""

__all__ = ["FNN"]

from .fnn import FNN
